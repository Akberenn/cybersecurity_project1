package com.tannur.SpringSecurityNew.controllers;

import com.tannur.SpringSecurityNew.models.Person;
import com.tannur.SpringSecurityNew.models.QuestionForm;
import com.tannur.SpringSecurityNew.models.Result;
import com.tannur.SpringSecurityNew.repositories.PeopleRepository;
import com.tannur.SpringSecurityNew.services.QuizService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Optional;

@Controller
public class MainController {

    @Autowired
    Result result;
    @Autowired
    QuizService qService;

    private final PeopleRepository peopleRepository;

    Boolean submitted = false;

    public MainController(PeopleRepository peopleRepository) {
        this.peopleRepository = peopleRepository;
    }

    @ModelAttribute("result")
    public Result getResult() {
        return result;
    }

    @GetMapping("/")
    public String home(Model m) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();

        Optional<Person> person = peopleRepository.findByUsername(currentPrincipalName);
        String role = "";
        if (person.get().getRole().equals("ROLE_ADMIN")) {
            role = person.get().getRole();
        }
        m.addAttribute("role", role);

        return "index.html";
    }

    @PostMapping("/quiz")
    public String quiz(@RequestParam String username, Model m, RedirectAttributes ra) {
        if(username.equals("")) {
            ra.addFlashAttribute("warning", "You must enter your name");
            return "redirect:/";
        }

        submitted = false;
        result.setUsername(username);

        QuestionForm qForm = qService.getQuestions();
        m.addAttribute("qForm", qForm);

        return "quiz.html";
    }

    @PostMapping("/submit")
    public String submit(@ModelAttribute QuestionForm qForm, Model m) {
        if(!submitted) {
            result.setTotalCorrect(qService.getResult(qForm));
            qService.saveScore(result);
            submitted = true;
        }

        return "result.html";
    }

    @GetMapping("/score")
    public String score(Model m) {
        List<Result> sList = qService.getTopScore();
        List<Integer> all = qService.getAllScore();
        m.addAttribute("sList", sList);
        m.addAttribute("all", all);

        return "scoreboard.html";
    }
}
